/* -------- Smooth Scroll for internal links -------- */
document.querySelectorAll('.nav a[href^="#"]').forEach(a=>{
  a.addEventListener('click', e=>{
    e.preventDefault();
    const id = a.getAttribute('href');
    const el = document.querySelector(id);
    if(!el) return;
    window.scrollTo({
      top: el.offsetTop - 70,
      behavior: 'smooth'
    });
  });
});

/* -------- Slider (auto every 2s, dots & hover pause) -------- */
const slides = Array.from(document.querySelectorAll('.slide'));
const dotsWrap = document.getElementById('sliderDots');

let current = 0;
let autoTimer = null;
const DUR = 2000; // 2 seconds

function renderDots(){
  slides.forEach((_,i)=>{
    const b = document.createElement('button');
    b.setAttribute('aria-label', `Go to slide ${i+1}`);
    b.addEventListener('click', ()=>goTo(i, true));
    dotsWrap.appendChild(b);
  });
}
function activateDot(){
  const dots = dotsWrap.querySelectorAll('button');
  dots.forEach((d,i)=> d.classList.toggle('active', i===current));
}
function goTo(index, manual=false){
  slides[current].classList.remove('active');
  current = (index + slides.length) % slides.length;
  slides[current].classList.add('active');
  activateDot();
  if(manual){ resetAuto(); }
}
function next(){ goTo(current+1); }
function startAuto(){ autoTimer = setInterval(next, DUR); }
function stopAuto(){ clearInterval(autoTimer); autoTimer=null; }
function resetAuto(){ stopAuto(); startAuto(); }

renderDots();
slides[0].classList.add('active');
activateDot();
startAuto();

const hero = document.querySelector('.hero');
hero.addEventListener('mouseenter', stopAuto);
hero.addEventListener('mouseleave', startAuto);

/* -------- Reveal on Scroll (IntersectionObserver) -------- */
const io = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add('in-view');
      io.unobserve(entry.target);
    }
  });
},{
  root:null, threshold: 0.15
});
document.querySelectorAll('.reveal').forEach(el=> io.observe(el));

/* -------- Parallax that reacts to scroll direction --------
   - Elements with .parallax and data-speed move differently
   - On scroll DOWN: move along +Y and slight +X
   - On scroll UP:   move along -Y and slight -X
   - subtle clamp for stability on long pages
*/
let lastY = window.scrollY;
let accum = 0;

function parallaxUpdate(){
  const nowY = window.scrollY;
  const dy = nowY - lastY;
  lastY = nowY;

  // accumulate movement, clamp
  accum += dy;
  accum = Math.max(-1200, Math.min(1200, accum));

  const dir = Math.sign(dy) || 1; // 1 down, -1 up (default 1)
  document.querySelectorAll('.parallax').forEach(el=>{
    const speed = parseFloat(el.dataset.speed || '0.1');
    // different vector for up vs down
    const moveX = dir > 0 ? speed * 6 : -speed * 6;
    const moveY = dir > 0 ? speed * 18 : -speed * 18;

    // base transform also includes a slow accumulated drift
    const driftX = (accum * speed * 0.02);
    const driftY = (accum * speed * 0.06);

    // read existing rotation/scale via CSS not needed; we append translate
    el.style.transform = `translate(${moveX + driftX}px, ${moveY + driftY}px)`;
  });
}
let ticking = false;
window.addEventListener('scroll', ()=>{
  if(!ticking){
    window.requestAnimationFrame(()=>{
      parallaxUpdate();
      ticking = false;
    });
    ticking = true;
  }
}, {passive:true});

/* -------- Active nav link highlight on scroll -------- */
const sections = ['home','menu','about','contact'].map(id=>document.getElementById(id));
const navLinks = Array.from(document.querySelectorAll('.nav-link'));
function highlightNav(){
  const y = window.scrollY + 90; // header offset
  let currentId = 'home';
  for(const sec of sections){
    if(sec && y >= sec.offsetTop) currentId = sec.id;
  }
  navLinks.forEach(a=> a.classList.toggle('active', a.getAttribute('href') === `#${currentId}`));
}
window.addEventListener('scroll', highlightNav, {passive:true});
highlightNav();

/* -------- Minor: keyboard navigation for slider (← →) -------- */
document.addEventListener('keydown', (e)=>{
  if(e.key === 'ArrowRight') { resetAuto(); next(); }
  if(e.key === 'ArrowLeft')  { resetAuto(); goTo(current-1); }
});
